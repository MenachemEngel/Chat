package interfaces;

public interface IUnSucceededResponse {

}
