package interfaces;

public interface ISucceededResponse {

}
