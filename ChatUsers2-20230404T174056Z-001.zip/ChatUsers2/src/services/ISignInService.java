package services;

import Kivun.Infra.Interfaces.IService;

public interface ISignInService extends IService{

}
