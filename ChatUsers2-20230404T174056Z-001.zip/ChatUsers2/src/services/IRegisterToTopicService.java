package services;

import Kivun.Infra.Interfaces.IService;

public interface IRegisterToTopicService extends IService{

}
